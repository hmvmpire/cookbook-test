import React from 'react';
import logo from './logo.svg';
import './App.css';

const recipes = [
  {
    author: "Jim",
    name: "Chicken Curry",
    description: "Delicious spicy chicken curry"
  },
  {
    author: "Aravind",
    name: "Hamburger",
    description: "Juicy burger with toppings and a soft bun",
  }
]

function App() {
  return (
    <div className="App">
    </div>
  );
}

export default App;
